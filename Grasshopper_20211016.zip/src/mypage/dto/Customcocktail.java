package mypage.dto;

public class Customcocktail {

}
